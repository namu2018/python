# -*- coding: utf-8 -*-

#%% 클래스 만들기 
#%% walk, eat가 반복이 된다.
class Human():
    def walk(self):
        print("걷는다")
        
    def eat(self):
        print("먹는다")
    
    def wave(self):
        print("손을 흔든다")

class Dog():
    def walk(self):
        print("걷는다")
    
    def eat(self):
        print("먹는다")
    
    def wag(self):
        print("꼬리를 흔든다")
        

#%% 클래스 객체 만들고, 메서드 만들기
person = Human()
person.walk()
person.eat()
person.wave()

dog = Dog()
dog.walk()
dog.eat()
dog.wag()

