# -*- coding: utf-8 -*-

class Car():
    def run(self):
        print("차가 달립니다")
    def stop(self):
        print("차가 멈춥니다.")
    def move(self):
        print("차가 움직입니다")

# Car를 상속받는 Class 선언해 보자.
# Truck - 트럭은 짐을 실을 수 있다.(load)
# Taxi - 택시는 영업을 할 수 있다.(sale)
# .. 기타 class 만들고 이를 실행해 보자.