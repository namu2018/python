# -*- coding: utf-8 -*-

#%% 클래스 만들기 
#%% walk, eat가 반복이 된다.
# 사람은 잠자는 것을 사람은 누워잔다.
# 개는 엎드려 잔다.
''' 반복되는 부분을 갖는 클래스를 하나 만들고 이를 상속시킨다.'''
class common():
    def walk(self):
        print("걷는다")
    def eat(self):
        print("먹는다")
    def sleep(self):
        print("잠잔다")
        
class Human(common):
    def wave(self):
        print("손을 흔든다")
    def sleep(self):               ### 오버라이딩 부분 
        print("누워잔다.")
        
class Dog(common):
    def wag(self):
        print("꼬리를 흔든다")
    def sleep(self):               ### 오버라이딩 부분 
        print("엎드려잔다.")

class bird(common):
    def wag(self):
        print("꼬리를 흔든다")

#%% 클래스 객체 만들고, 메서드 만들기
# 오버라이딩에 의해 다른 결과가 나타나게 된다.
person = Human()
person.sleep()

dog = Dog()
dog.sleep()

bird = bird()
bird.sleep()