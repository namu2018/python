# -*- coding: utf-8 -*-

#%% 슈퍼 클래스
# 자식 클래스에서 부모 클래스의 내용을 사용하고 싶을 때,
# Human의 손을 흔든다. 그리고 걷는다.
# Human의 wave를 이용하고, 부모클래스의 eat를 호출한다.

class common():
    def walk(self):
        print("걷는다")
        
    def eat(self):
        print("먹는다")
        
    def greet(self):
        print("인사한다.")
        
class Human(common):
    def wave(self):
        print("손을 흔든다")

    def greet(self):
        self.wave()
        super().greet()    # super를 이용 
        
class Dog(common):
    def wag(self):
        print("꼬리를 흔든다")
        

#%% 클래스 객체 만들고, 메서드 만들기
person = Human()
person.greet()

#&& 개에 대해서도 동일하게 super() 클래스를 이용하여 완성시켜 보자.

