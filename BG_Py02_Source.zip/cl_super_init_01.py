# -*- coding: utf-8 -*-

#%% 클래스 만들기 - _init_
# 여기서 대상을 넣어보자. 
# 철수가 손을 흔든다.(Human)
# 세퍼드가 꼬리를 흔든다.
class common():
    def __init__(self, name):
        self.name = name
    
    def walk(self):
        print("걷는다")
    def eat(self):
        print("먹는다")
    def sleep(self):
        print("{} 잠잔다".format(self.name))
        
class Human(common):
    def wave(self):
        print("손을 흔든다")
        
class Dog(common):
    def wag(self):
        print("꼬리를 흔든다")


#%% 클래스 객체 만들고, 메서드 만들기
# 같은 결과가 온다. 
person = Human("철수가")
person.sleep()

dog = Dog("세퍼드")
dog.sleep()

