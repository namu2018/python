# -*- coding: utf-8 -*-

#%% 클래스 만들기 
#%% walk, eat가 반복이 된다.
''' 반복되는 부분을 갖는 클래스를 하나 만들고 이를 상속시킨다.'''
class common():
    def walk(self):
        print("걷는다")
        
    def eat(self):
        print("먹는다")
        
class Human(common):
    def wave(self):
        print("손을 흔든다")

class Dog(common):
    def wag(self):
        print("꼬리를 흔든다")
        

#%% 클래스 객체 만들고, 메서드 만들기
person = Human()
person.walk()
person.eat()
person.wave()

dog = Dog()
dog.walk()
dog.eat()
dog.wag()

